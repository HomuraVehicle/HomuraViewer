#ifndef HMR_COMPASS_CPP_INC
#define HMR_COMPASS_CPP_INC 102
#

#include"hmrCompass.hpp"

const unsigned char hmr::cCompassMsgAgent::CorrectionMeasureNum=10;

#
#endif
