#ifndef HMR_DXMESSAGE_INC
#define HMR_DXMESSAGE_INC 100
#

#
#endif
