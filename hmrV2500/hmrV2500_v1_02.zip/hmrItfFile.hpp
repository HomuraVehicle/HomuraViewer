#ifndef HMR_ITFFILE_INC
#define HMR_ITFFILE_INC 100
#
/*===hmrFile===
���O�t�@�C�����Ǘ�����N���X�C���^�[�t�F�[�X
*/
#include<string>
namespace hmr{
	class itfFileAgent{
	public:
		virtual void open(const std::string& Path_)=0;
		virtual void load(const std::string& Path_,const std::string& FileName_="")=0;
		virtual void save()=0;
		virtual void close()=0;
	};
	class itfFile{
	private://Vari
		hmDir Dir;
		bool FileFlag;
	public://Vari
		std::vector<hmrFile::abtFileType*> FileTypes;
	public://Func
		hmrFile(){
			Dir=hm::getCDir();
			FileFlag=false;
		}
		void work();
		bool open(bool _NewOnlyFlag);
		bool load(const std::string& _name);
		bool is_open()const{return FileFlag;}
		bool close();
	};
}
#endif
