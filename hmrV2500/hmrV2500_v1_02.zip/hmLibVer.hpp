//using version of hmLib
#define USE_HMLIB 20900
#define USE_HMDIR   101
