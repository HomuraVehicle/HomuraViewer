#ifndef HMR_DXCOMPASSMUI_INC
#define HMR_DXCOMPASSMUI_INC 101
#
/*===hmrDxCompassMUI===
hmrDxCompassMUI v1_01/130519 iwahori
	�␳�l�擾�{�^���ǉ��i�ꏊ�͂Ă��Ƃ��j
hmrDxCompassMUI v1_00/130511 hmIto
	�ǉ�
*/

#include"hmLibVer.hpp"
#include<string>
#include<sstream>
#include<hmLib_v2/dxObject.hpp>
#include<hmLib_v2/dxColorSet.hpp>
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include<hmLib_v3_05/inquiries.hpp>
#include"coordinates.hpp"
#include"hmrData.hpp"
#include"hmrDxBUI.hpp"
#include"hmrCompassData.hpp"

namespace hmr{
	//x240*yNONE
	class dxosCompassMUI:public dxosBUI{
		typedef hmLib::coordinates3D::position position;
		typedef hmLib::coordinates3D::polar polar;
		hmLib::signals::unique_connections SignalConnections;

		position pos;
		clock::time_point time;

		void setCompassData_and_time(position pos_, clock::time_point time_){
			pos = pos_;
			time = time_;
		}
	public:
		//hmLib::inquiries::inquiry<position> inquiry_getCompassPossition;
		//hmLib::inquiries::inquiry<polar> inquiry_getCompassPolar;
		//hmLib::inquiries::inquiry<clock::time_point> inquiry_getTime;
		void slot_setCompassData_and_time(boost::signals2::signal<void(position, clock::time_point)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](position pos, clock::time_point t)->void{this->setCompassData_and_time(pos,t);}));		
		}

		dxosBUIWaitableBoolBut IsDataModeMUIBut;

		dxosBUIWaitableBut CorrectionDataBut;
		hmLib::inquiries::inquiry<position> inquiry_getCorrectionValue;
	public:
		dxosCompassMUI():dxosBUI("Compass",30,105),IsDataModeMUIBut(this),CorrectionDataBut(this){}
	public:
		int normal_draw(dxO& dxo)override{
			try{
				try{
					IsDataModeMUIBut.set(Pint(70,20),"Data");
					dxo.draw(Pint(5,5),IsDataModeMUIBut);
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(5,5),dxoStrP(Pint(70,20),"Data",getClr(error,strobj)));
				}

				try{
					auto Pol= cCompass::transPos_to_Polar(pos);
					dxo.draw(Pint(80,5),dxoStrP(Pint(70,20),(boost::format("Y:%.1f")%Pol.phi).str(),getTimeStrClr(time)));
					dxo.draw(Pint(155,5),dxoStrP(Pint(70,20),(boost::format("P:%.1f")%Pol.theta).str(),getTimeStrClr(time)));
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(80,5),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
					dxo.draw(Pint(155,5),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				}
			}catch(const hmLib::exceptions::exception& Excp){
				dxo.draw(Pint(0,0),dxoButIO(getSize(),std::string("=ERR=")+Excp.what(),getClr(error,butobj),true,CLR::White,ALI::left));
			}

			return 0;
		}
		int extend_draw(dxO& dxo)override{
			normal_draw(dxo);

			try{
				auto Value= pos;
				dxo.draw(Pint(5,30),dxoStrP(Pint(70,20),(boost::format("X:%.1f")%Value.x).str(),getTimeStrClr(time)));
				dxo.draw(Pint(80,30),dxoStrP(Pint(70,20),(boost::format("Y:%.1f")%Value.y).str(),getTimeStrClr(time)));
				dxo.draw(Pint(155,30),dxoStrP(Pint(70,20),(boost::format("Z:%.1f")%Value.z).str(),getTimeStrClr(time)));
			}catch(const hmLib::inquiries::unconnected_exception&){
				dxo.draw(Pint(5,30),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				dxo.draw(Pint(80,30),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				dxo.draw(Pint(155,30),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
			}

			try{
				CorrectionDataBut.set(Pint(70,20),"�␳");
				dxo.draw(Pint(5,55),CorrectionDataBut);
			}catch(const hmLib::inquiries::unconnected_exception&){
				dxo.draw(Pint(5,55),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
			}

			try{
				auto Value=inquiry_getCorrectionValue();
				dxo.draw(Pint(5,80),dxoStrP(Pint(70,20),(boost::format("��X:%.1f")%Value.x).str(),getTimeStrClr(time)));
				dxo.draw(Pint(80,80),dxoStrP(Pint(70,20),(boost::format("��Y:%.1f")%Value.y).str(),getTimeStrClr(time)));
				dxo.draw(Pint(155,80),dxoStrP(Pint(70,20),(boost::format("��Z:%.1f")%Value.z).str(),getTimeStrClr(time)));
			}catch(const hmLib::inquiries::unconnected_exception&){
				dxo.draw(Pint(5,80),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				dxo.draw(Pint(80,80),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				dxo.draw(Pint(155,80),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
			}

			return 0;
		}
		status getStatus()const override{
			if(IsDataModeMUIBut.Pic.is_connect() && IsDataModeMUIBut.Pic())return normal;
			else return invalid;
		}
	};
}
#
#endif
