#ifndef HMR_INFRARED_INC
#define HMR_INFRARED_INC 102
#
/*=============hmrInfraRed===============
hmrInfraRed v1_02/130602 iwahori
	�L�[�{�[�h�E�p�b�h�p��slot_setDataMode()��ǉ�(������void(void)�ɂȂ��Ă���)
hmrInfraRed v1_01/130427 iwahori
	Flagirl�ւ�inquiry���쐬
hmrInfraRed v1_00/130420 iwahori
	cInfraRedMsgAgent��signal-slot,inquiry-contact�ւ̑Ή�����
*/

#include "hmLibVer.hpp"
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include <hmLib_v3_05/inquiries.hpp>
#include "hmrItfMessage.hpp"
#include "hmrFlagirl.hpp"
#include "hmrADC.h"

namespace hmr{
	class cInfraRedMsgAgent:public itfMessageAgent{
	private:
		flagirl DataModeFlagirl;
		double InTemperature;
		double OutTemperature;
		double Temperature;
//		static const double D_ADMaxValue;
		clock::time_point Time;
		static double toInfraRedIn(unsigned int Value_){return (Value_*2.*4096./D_ADMaxValue-1084.)/39.905;}
		static double toInfraRedOut(unsigned int Value_){return (Value_*2.*4096./D_ADMaxValue-1645.);}
		static double toInfraRed(double Out_,double In_){return (Out_*0.2043+In_)/(1+0.00069*Out_);}
	public:
		cInfraRedMsgAgent()
			:DataModeFlagirl()
			,InTemperature(0.)
			,OutTemperature(0.)
			,Temperature(0.)
			,Time(){
		}
		bool listen(datum::time_point Time_,bool IsErr_,const std::string& Data_)override{
			if(Data_.size()==0)return true;

			if(static_cast<unsigned char>(Data_[0])==0x00){
				if(Data_.size()!=5)return true;
				unsigned int OutValue=static_cast<unsigned char>(Data_[1])+256*static_cast<unsigned char>(Data_[2]);
				unsigned int InValue=static_cast<unsigned char>(Data_[3])+256*static_cast<unsigned char>(Data_[4]);
				InTemperature=toInfraRedIn(InValue);
				OutTemperature=toInfraRedOut(OutValue);
				Temperature=toInfraRed(OutTemperature,InTemperature);
				Time=Time_;
				return false;
			}else if(static_cast<unsigned char>(Data_[0])==0x10){
				if(Data_.size()!=1)return true;
				DataModeFlagirl.set_pic(true);
				return false;
			}else if(static_cast<unsigned char>(Data_[0])==0x11){
				if(Data_.size()!=1)return true;
				DataModeFlagirl.set_pic(false);
				return false;
			}
			return true;
		}
		bool talk(std::string& Str)override{
			if(DataModeFlagirl.talk()){
				if(DataModeFlagirl.request())Str.push_back(static_cast<unsigned char>(0x10));
				else Str.push_back(static_cast<unsigned char>(0x11));
				return false;
			}
			return true;
		}
		void setup_talk(void)override{
			DataModeFlagirl.setup_talk();	
		}
	private:
		hmLib::signals::unique_connections SignalConnections;
		hmLib::inquiries::unique_connections InquiryConnections;

		void setDataMode(bool Val_){DataModeFlagirl.set_request(Val_);}
		std::pair<double,double> getInOutTemperature()const{
			return std::make_pair(InTemperature,OutTemperature);
		}
	public:
		void slot_setDataMode(boost::signals2::signal<void(bool)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](bool b)->void{this->setDataMode(b);}));
		}
		void slot_setDataMode(boost::signals2::signal<void(void)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](void)->void{this->setDataMode(!DataModeFlagirl.request());}));
		}
		void contact_getInOutTemperature(hmLib::inquiries::inquiry<std::pair<double,double>>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,[&](void)->std::pair<double,double>{return this->getInOutTemperature();}));
		}
		void contact_getTemperature(hmLib::inquiries::inquiry<double>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,Temperature));
		}
		void contact_getTime(hmLib::inquiries::inquiry<clock::time_point>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,Time));
		}
		void contact_getPicDataMode(hmLib::inquiries::inquiry<bool>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,[&](void)->bool{return DataModeFlagirl.pic();}));
		}
		void contact_getRequestDataMode(hmLib::inquiries::inquiry<bool>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,[&](void)->bool{return DataModeFlagirl.request();}));
		}
	};
}

#
#endif