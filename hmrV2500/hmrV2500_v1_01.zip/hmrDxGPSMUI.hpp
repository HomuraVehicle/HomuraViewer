#ifndef HMR_DXGPSMUI_INC
#define HMR_DXGPSMUI_INC 100
#
/*===hmrThermo===
hmrDxGPSMsgAgentUI v1_00/130414 iwahori
	�쐬
*/

#include"hmLibVer.hpp"
#include<string>
#include<sstream>
#include<hmLib_v2/dxObject.hpp>
#include<hmLib_v2/dxColorSet.hpp>
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include<hmLib_v3_05/inquiries.hpp>
#include"hmrData.hpp"
#include"hmrDxMUI.hpp"
#include"hmrDxTools.hpp"
#include"hmrGPSDataSet.hpp"
namespace hmr{
	//x240*yNONE
	class dxosGPSMUI:public dxosMUI{
	public:
		hmLib::inquiries::inquiry<GPSDataSet> inquiry_getGPSData;

		dxosWaitableBoolMUIBut IsDataModeMUIBut;
	public:
		dxosGPSMUI():dxosMUI(Pint(240,80),Pint(240,80)),IsDataModeMUIBut(this){}
	public:
		int normal_draw(dxO& dxo)override{
			try{
				try{
					IsDataModeMUIBut.set(Pint(75,25),"GPS");
					dxo.draw(Pint(0,0),IsDataModeMUIBut);
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(5,5),dxoStrP(Pint(70,20),"GPS",getClr(error,strobj)));
				}

				try{
					auto Data=inquiry_getGPSData();
					auto Time=Data.getTime();
					dxo.draw(Pint(80, 5),dxoStrP(Pint(145,20),(boost::format("N:%.4f")%Data.getPos().x).str(),getTimeStrClr(Time)));
					dxo.draw(Pint(80,30),dxoStrP(Pint(145,20),(boost::format("E:%.4f")%Data.getPos().y).str(),getTimeStrClr(Time)));
					dxo.draw(Pint(80,55),dxoStrP(Pint(145,20),(boost::format("H:%.4f")%Data.getHeight()).str(),getTimeStrClr(Time)));
					dxo.draw(Pint(5,30),dxoStrP(Pint(70,20),(boost::format("GPS#:%d")%Data.getUseGPS()).str(),getTimeStrClr(Time)));
					dxo.draw(Pint(5,55),dxoStrP(Pint(70,20),(boost::format("Fail:%d")%static_cast<int>(Data.getFail())).str(),getTimeStrClr(Time)));
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(80,5),dxoStrP(Pint(145,20),"NoCnct",getClr(error,strobj)));
					dxo.draw(Pint(80,30),dxoStrP(Pint(145,20),"NoCnct",getClr(error,strobj)));
					dxo.draw(Pint(80,55),dxoStrP(Pint(145,20),"NoCnct",getClr(error,strobj)));
					dxo.draw(Pint(5,30),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
					dxo.draw(Pint(5,55),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				}

			}catch(const hmLib::exceptions::exception& Excp){
				dxo.draw(Pint(0,0),dxoButIO(getSize(),std::string("=ERR=")+Excp.what(),getClr(error,butobj),true,CLR::White,ALI::left));
			}

			return 0;
		}
		int extend_draw(dxO& dxo)override{
			return normal_draw(dxo);
		}
	};
}
#
#endif
