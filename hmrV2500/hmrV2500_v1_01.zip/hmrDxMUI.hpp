#ifndef HMR_DXMUI_INC
#define HMR_DXMUI_INC 100
#
#include"hmLibVer.hpp"
#include<hmLib_v3_05/inquiries.hpp>
#include<hmLib_v3_05/signals.hpp>
#include<hmLib_v3_05/exceptions.hpp>
#include<hmLib_v2/dxColorSet.hpp>
#include<hmLib_v2/dxObject.hpp>
#include<hmLib_v2/dxArea.hpp>
#include"hmrDxTools.hpp"
#include"hmrData.hpp"
namespace hmr{
	//MessageAgent�pUI�̊��N���X
	class dxosMUI:public dxReObject,public hmoBox{
	public:
		struct color_set{
			dxRGB Background;
			dxRGB Thema;
			dxRGB NormalBut;
			dxRGB WaitBut;
			dxRGB ErrorBut;
			dxRGB NormalStr;
			dxRGB WaitStr;
			dxRGB ErrorStr;
			dxRGB PresentStr;
			dxRGB RecentStr;
			dxRGB PastStr;
			color_set(){}
			void set(
				const dxRGB& Background_,
				const dxRGB& Thema_,
				const dxRGB& NormalBut_,
				const dxRGB& WaitBut_,
				const dxRGB& ErrorBut_,
				const dxRGB& NormalStr_,
				const dxRGB& WaitStr_,
				const dxRGB& ErrorStr_,
				const dxRGB& PresentStr_,
				const dxRGB& RecentStr_,
				const dxRGB& PastStr_){
				Background=Background_;
				Thema=Thema_;
				NormalBut=NormalBut_;
				WaitBut=WaitBut_;
				ErrorBut=ErrorBut_;
				NormalStr=NormalStr_;
				WaitStr=WaitStr_;
				ErrorStr=ErrorStr_;
				PresentStr=PresentStr_;
				RecentStr=RecentStr_;
				PastStr=PastStr_;
			}
		};
	public:
		enum status{normal,wait,error};
		enum time{present,recent,past};
		enum object{butobj,strobj};
		static color_set DefaultClr;
	private:
		const color_set* pClrSet;
	private:
		Pint NormalSize;
		Pint ExtendSize;
		bool IsExtend;
	public:
		virtual int normal_draw(dxO& dxo)=0;
		virtual int extend_draw(dxO& dxo)=0;
	public:
		int redraw(dxO& dxo)override{
			if(IsExtend){
				if(dxo.draw(Pint(0,0),dxoButLRIO(size,"",pClrSet->Background,IsExtend))==10)IsExtend=!IsExtend;
				dxo.draw(Pint(0,0),dxoBox(Pint(75,25),pClrSet->Thema));
				return extend_draw(dxo);
			}else{
				if(dxo.draw(Pint(0,0),dxoButLRIO(size,"",pClrSet->Background,IsExtend))==10)IsExtend=!IsExtend;
				dxo.draw(Pint(0,0),dxoBox(Pint(75,25),pClrSet->Thema));
				return normal_draw(dxo);
			}
		}
		Pint getSize()const{return size;}
		void setClrSet(const color_set* pClrSet_){
			pClrSet=pClrSet_;
		}
		const dxRGB& getClr(status Sta_,object Obj_)const{
			switch(Obj_){
			case butobj:
				switch(Sta_){
				case normal:
					return pClrSet->NormalBut;
				case wait:
					return pClrSet->WaitBut;
				case error:
					return pClrSet->ErrorBut;
				default:
					hmLib_throw(hmLib::exceptions::invalid_request,"Invalid status.");
				}
			case strobj:
				switch(Sta_){
				case normal:
					return pClrSet->NormalStr;
				case wait:
					return pClrSet->WaitStr;
				case error:
					return pClrSet->ErrorStr;
				default:
					hmLib_throw(hmLib::exceptions::invalid_request,"Invalid status.");
				}
			default:
				hmLib_throw(hmLib::exceptions::invalid_request,"Invalid object.");
			}
		}
		time getTime(hmr::clock::time_point Time_)const{
			if(hmr::clock::now()-Time_>std::chrono::seconds(5))return present;
			else if(hmr::clock::now()-Time_>std::chrono::seconds(15))return recent;
			else return past;
		}
		const dxRGB& getBGClr()const{return pClrSet->Background;}
		const dxRGB& getTimeStrClr(hmr::clock::time_point Time_)const{
			switch(getTime(Time_)){
			case present:
				return pClrSet->PresentStr;
			case recent:
				return pClrSet->RecentStr;
			case past:
				return pClrSet->PastStr;
			default:
				hmLib_throw(hmLib::exceptions::invalid_request,"Invalid Time Category");
			}
		}
	public:
		virtual void setArea()override{
			if(IsExtend)size=ExtendSize;
			else size=NormalSize;
		}
	public:
		dxosMUI(Pint NormalSize_,Pint ExtendSize_):NormalSize(NormalSize_),ExtendSize(ExtendSize_),IsExtend(false),pClrSet(&DefaultClr){}
		virtual ~dxosMUI(){}
	};
	//�f�[�^�̎擾���Ԃɉ����ĕ\���F��ς���I�u�W�F�N�g
	class dxoTimeStr:public dxReObject,public hmoBox{
	private:
		const dxosMUI* pMUI;
	public:
		std::string Str;
		hmr::clock::time_point Time;
		ALI::ALIGN Ali;
	public:
		dxoTimeStr(const dxosMUI* pMUI_,Pint Size_,const std::string& Str_,hmr::clock::time_point Time_,ALI::ALIGN Ali_=ALI::center):pMUI(pMUI_),hmoBox(Size_),Str(Str_),Time(Time_),Ali(Ali_){}
	public:
		int redraw(dxO& dxo)override{
			dxo.draw(Pint(0,0),dxoStrP(size,Str,pMUI->getTimeStrClr(Time),Ali));
			return 0;
		}
	};
	class dxosWaitableMUIBut:public dxReObject,public hmoBox{
	private:
		const dxosMUI* pMUI;
	public:
		boost::signals2::signal<void(void)> Signal;
		hmLib::inquiries::inquiry<bool> Req;
		std::string Str;
	public:
		dxosWaitableMUIBut(const dxosMUI* pMUI_):pMUI(pMUI_){}
		void set(Pint Size_,const std::string& Str_){
			hmoBox::size=Size_;
			Str=Str_;
		}
	public:
		int redraw(dxO& dxo)override{
			bool OnOff_Req=Req();

			if(dxo.draw(Pint(0,0),dxoWaitableBoolBut(size,Str,pMUI->getClr(dxosMUI::normal,dxosMUI::butobj),CLR::White,pMUI->getClr(dxosMUI::wait,dxosMUI::butobj),CLR::White,OnOff_Req,false))==1){
				Signal();
			}
			return 0;
		}
	};
	class dxosWaitableBoolMUIBut:public dxReObject,public hmoBox{
	private:
		const dxosMUI* pMUI;
	public:
		boost::signals2::signal<void(bool)> Signal;
		hmLib::inquiries::inquiry<bool> Req;
		hmLib::inquiries::inquiry<bool> Pic;
		std::string Str;
	public:
		dxosWaitableBoolMUIBut(const dxosMUI* pMUI_):pMUI(pMUI_){}
		void set(Pint Size_,const std::string& Str_){
			hmoBox::size=Size_;
			Str=Str_;
		}
	public:
		int redraw(dxO& dxo)override{
			bool OnOff_Req=Req();
			bool OnOff_Pic=Pic();

			if(dxo.draw(Pint(0,0),dxoWaitableBoolBut(size,Str,pMUI->getClr(dxosMUI::normal,dxosMUI::butobj),CLR::White,pMUI->getClr(dxosMUI::wait,dxosMUI::butobj),CLR::White,OnOff_Req,OnOff_Pic))==1){
				Signal(!OnOff_Req);
			}
			return 0;
		}
	};
	//dxosMUI��o�^����ƁA�T�C�h�o�[(240*720)�Ƃ��ĕ\�����Ă����B
	class dxosMUISideDisplay:public dxReObject,public hmoBox{
		typedef std::vector<dxosMUI*> containor;
		typedef containor::iterator iterator;
	private:
		containor MUIPtrVec;
		dxScrlFrame MUIFrame;
	public:
		class dxFnMUISideDisplay:public dxFn{
			iterator Begin;
			iterator End;
		public:
			dxFnMUISideDisplay(iterator Begin_,iterator End_):Begin(Begin_),End(End_){}
			virtual int fndraw(dxO& dxo)override{
				int Pos=0;
				for(auto Itr=Begin;Itr!=End;++Itr){
					dxo.draw(Pint(0,Pos),*(*Itr));
					Pos+=(*Itr)->getSize().y;
				}
				return 0;
			}
		};
	public:
		void insert(dxosMUI* pMUI_){
			MUIPtrVec.push_back(pMUI_);
		}
	public:
		dxosMUISideDisplay():hmoBox(Pint(240,720)){}
		virtual int redraw(dxO& dxo){
			try{
				dxFnMUISideDisplay Fn(MUIPtrVec.begin(),MUIPtrVec.end());
				MUIFrame.set(Fn,size,CLR::DarkSoftRed,dxDMode(196),dxDMode(0));
				dxo.draw(Pint(0,0),MUIFrame);

			}catch(const std::exception& Excp){
				dxo.draw(Pint(0,0),dxoButIO(size,Excp.what(),CLR::Red,false));
			}
			return 0;
		}
	};
}
#
#endif
