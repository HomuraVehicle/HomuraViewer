#ifndef INC_HMRGYRO_CPP_INC
#define INC_HMRGYRO_CPP_INC 101
#

#include"hmrGyro.hpp"

//const unsigned char hmr::cGyroMsgAgent::CorrectionMeasureNum=10;

#
#endif
