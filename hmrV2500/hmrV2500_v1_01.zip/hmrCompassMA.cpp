#ifndef HMR_COMPASS_MA_CPP_INC
#define HMR_COMPASS_MA_CPP_INC 103
#

#include"hmrCompassMA.hpp"

const unsigned char hmr::cCompassMsgAgent::CorrectionMeasureNum=10;

#
#endif
