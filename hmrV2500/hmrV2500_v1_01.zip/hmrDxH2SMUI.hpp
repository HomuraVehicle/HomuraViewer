#ifndef HMR_DXH2SMUI_INC
#define HMR_DXH2SMUI_INC 100
#
/*===hmrDxH2SMUI===
hmrDxH2SMUI v1_00/130519 iwahori
	�쐬
*/

#include"hmLibVer.hpp"
#include<string>
#include<sstream>
#include<hmLib_v2/dxObject.hpp>
#include<hmLib_v2/dxColorSet.hpp>
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include<hmLib_v3_05/inquiries.hpp>
#include"hmrData.hpp"
#include"hmrDxMUI.hpp"
#include"hmrDxTools.hpp"
namespace hmr{
	//x240*yNONE
	class dxosH2SMUI:public dxosMUI{
	public:
		hmLib::inquiries::inquiry<double> inquiry_getValue;
		hmLib::inquiries::inquiry<clock::time_point> inquiry_getTime;

		dxosWaitableBoolMUIBut IsDataModeMUIBut;
	public:
		dxosH2SMUI():dxosMUI(Pint(240,30),Pint(240,30)),IsDataModeMUIBut(this){}
	public:
		int normal_draw(dxO& dxo)override{
			try{
				try{
					IsDataModeMUIBut.set(Pint(75,25),"H2S");
					dxo.draw(Pint(0,0),IsDataModeMUIBut);
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(5,5),dxoStrP(Pint(70,20),"H2S",getClr(error,strobj)));
				}

				try{
					dxo.draw(Pint(80,5),dxoTimeStr(this,Pint(70,20),(boost::format("%.1fppm")%inquiry_getValue()).str(),inquiry_getTime()));
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(80,5),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				}


			}catch(const hmLib::exceptions::exception& Excp){
				dxo.draw(Pint(0,0),dxoButIO(getSize(),std::string("=ERR=")+Excp.what(),getClr(error,butobj),true,CLR::White,ALI::left));
			}

			return 0;
		}
		int extend_draw(dxO& dxo)override{
			return normal_draw(dxo);
		}
	};
}
#
#endif
