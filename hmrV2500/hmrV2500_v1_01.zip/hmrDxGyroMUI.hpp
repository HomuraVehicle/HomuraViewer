#ifndef HMR_DXGYROEMUI_INC
#define HMR_DXGYROMUI_INC 100
#
/*===hmrDxGyroMUI===
hmrDxGyroMUI v1_00/130519 iwahori
	�Ƃ肠�����쐬�D�␳�l�擾�{�^���ǉ�
	�W���C���p�̃f�[�^�N���X���ł��Ă��Ȃ��̂łق�Accele�̃R�s�[
*/

#include"hmLibVer.hpp"
#include<string>
#include<sstream>
#include<hmLib_v2/dxObject.hpp>
#include<hmLib_v2/dxColorSet.hpp>
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include<hmLib_v3_05/inquiries.hpp>
#include"coordinates.hpp"
#include"hmrData.hpp"
#include"hmrDxMUI.hpp"
namespace hmr{
	//x240*yNONE
	class dxosGyroMUI:public dxosMUI{
		typedef hmLib::coordinates3D::angle angle;
	public:
		hmLib::inquiries::inquiry<angle> inquiry_getGyroData;
		hmLib::inquiries::inquiry<clock::time_point> inquiry_getTime;

		dxosWaitableBoolMUIBut IsDataModeMUIBut;

		dxosWaitableMUIBut CorrectionDataBut;
		hmLib::inquiries::inquiry<angle> inquiry_getCorrectionValue;

	public:
		dxosGyroMUI():dxosMUI(Pint(240,55),Pint(240,105)),IsDataModeMUIBut(this),CorrectionDataBut(this){}
	public:
		int normal_draw(dxO& dxo)override{
			try{
				try{
					IsDataModeMUIBut.set(Pint(75,25),"�p���x");
					dxo.draw(Pint(0,0),IsDataModeMUIBut);
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(0,0),dxoStrP(Pint(75,25),"�p���x",getClr(error,strobj)));
				}

				try{
					auto Value=inquiry_getGyroData();
					dxo.draw(Pint(5,30),dxoStrP(Pint(70,20),(boost::format("R:%.1f")%Value.roll).str(),getTimeStrClr(inquiry_getTime())));
					dxo.draw(Pint(80,30),dxoStrP(Pint(70,20),(boost::format("P:%.1f")%Value.pitch).str(),getTimeStrClr(inquiry_getTime())));
					dxo.draw(Pint(155,30),dxoStrP(Pint(70,20),(boost::format("Y:%.1f")%Value.yaw).str(),getTimeStrClr(inquiry_getTime())));
				}catch(const hmLib::inquiries::unconnected_exception&){
					dxo.draw(Pint(5,30),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
					dxo.draw(Pint(80,30),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
					dxo.draw(Pint(155,30),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				}

			}catch(const hmLib::exceptions::exception& Excp){
				dxo.draw(Pint(0,0),dxoButIO(getSize(),std::string("=ERR=")+Excp.what(),getClr(error,butobj),true,CLR::White,ALI::left));
			}

			return 0;
		}
		int extend_draw(dxO& dxo)override{
			normal_draw(dxo);

			try{
				CorrectionDataBut.set(Pint(70,20),"�␳");
				dxo.draw(Pint(5,55),CorrectionDataBut);
			}catch(const hmLib::inquiries::unconnected_exception&){
				dxo.draw(Pint(5,55),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
			}

			try{
				auto Value=inquiry_getCorrectionValue();
				dxo.draw(Pint(5,80),dxoStrP(Pint(70,20),(boost::format("��R:%.1f")%Value.roll).str(),getTimeStrClr(inquiry_getTime())));
				dxo.draw(Pint(80,80),dxoStrP(Pint(70,20),(boost::format("��P:%.1f")%Value.pitch).str(),getTimeStrClr(inquiry_getTime())));
				dxo.draw(Pint(155,80),dxoStrP(Pint(70,20),(boost::format("��Y:%.1f")%Value.yaw).str(),getTimeStrClr(inquiry_getTime())));
			}catch(const hmLib::inquiries::unconnected_exception&){
				dxo.draw(Pint(5,80),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				dxo.draw(Pint(80,80),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
				dxo.draw(Pint(155,80),dxoStrP(Pint(70,20),"NoCnct",getClr(error,strobj)));
			}

			return 0;
		}
	};
}
#
#endif
