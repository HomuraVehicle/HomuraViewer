#ifndef HMR_DXGPSKASHMIR_INC
#define HMR_DXGPSKASHMIR_INC
#
#include<hmLib_v3_05/signals.hpp>
#include<hmLib_v3_05/inquiries.hpp>
#include"hmLibVer.hpp"
#include<hmLib_v2/dxObject.hpp>
#include<hmLib_v2/dxPad.hpp>
#include<hmLib_v2/dxColorSet.hpp>
namespace hmr{
	class dxosGPSKashmirBut:public dxReObject,public hmoBox{
	public:
		boost::signals2::signal<void(void)> signal_connect;
		boost::signals2::signal<void(void)> signal_disconnect;
		hmLib::inquiries::inquiry<bool> inquiry_is_connect;
	public:
		dxosGPSKashmirBut(Pint size_):hmoBox(size_){}
		int redraw(dxO& dxo)override{
			try{
				if(inquiry_is_connect()){
					if(dxo.draw(Pint(0,0),dxoBut(size,"Cnct",CLR::SoftGreen))<0){
						signal_disconnect();
					}
				}else{
					if(dxo.draw(Pint(0,0),dxoBut(size,"No Cnct",CLR::SoftRed))<0){
						signal_connect();
					}
				}
			}catch(const hmLib::inquiries::unconnected_exception&){
				dxo.draw(Pint(0,0),dxoBut(size,"Error",CLR::SoftRed));
			}
			return 0;
		}
	};
}
#
#endif
