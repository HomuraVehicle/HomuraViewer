#ifndef HMR_INFRARED_CPP_INC
#define HMR_INFRARED_CPP_INC 102
#

#include"hmrInfraRed.hpp"

//const double hmr::cInfraRedMsgAgent::D_ADMaxValue=4096.;

#
#endif