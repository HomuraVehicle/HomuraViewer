#ifndef HMR_H2S_CPP_INC
#define HMR_H2S_CPP_INC 100
#

#include"hmrH2S.hpp"

//const double hmr::cH2SMsgAgent::D_ADMaxValue=4096.;

#
#endif