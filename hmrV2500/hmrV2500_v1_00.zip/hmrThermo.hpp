#ifndef HMR_THERMO_INC
#define HMR_THERMO_INC 102
#
/*===hmrThermo===
hmrThermo v1_02/130602 iwahori
	�L�[�{�[�h�E�p�b�h�p��slot_setDataMode()��ǉ�(������void(void)�ɂȂ��Ă���)
hmrThermo v1_01/130414 iwahori
	���x�f�[�^�̎󂯓n�����@��signal���񂩂�inquiry�ɕύX
hmrThermo v1_00/130414 iwahori
	cThermoMsgAgent��signal-slot�ւ̑Ή�����
*/
#include "hmLibVer.hpp"
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include <hmLib_v3_05/inquiries.hpp>
#include "hmrItfMessage.hpp"
#include "hmrFlagirl.hpp"

namespace hmr{
	class cThermoMsgAgent:public itfMessageAgent{
	private:
		flagirl DataModeFlagirl;
		double Temperature;
		clock::time_point Time;
	public:
		static double toTemperature(unsigned char LowByte,unsigned char HighByte){
			unsigned int tmp=static_cast<unsigned int>(LowByte+HighByte*256);
			return static_cast<double>(tmp);
	//		return (_Value*2*4096./D_ADMaxValue-1069.3)/39.173;
		}
		bool listen(datum::time_point Time_, bool Err_,const std::string& Data_)override{
				if(Data_.size()==0)return true;

				if(static_cast<unsigned char>(Data_[0])==0x00){
					if(Data_.size()!=3)return true;
					//�f�[�^�����x�ɕϊ�
					Temperature=toTemperature(static_cast<unsigned char>(Data_[1]),static_cast<unsigned char>(Data_[2]));
					Time=Time_;
					return false;
				}else if(static_cast<unsigned char>(Data_[0])==0x10){
					if(Data_.size()!=1)return true;
					DataModeFlagirl.set_pic(true);
					return false;
				}else if(static_cast<unsigned char>(Data_[0])==0x11){
					if(Data_.size()!=1)return true;
					DataModeFlagirl.set_pic(false);
					return false;
				}
				return true;
		}
		bool talk(std::string& Str)override{
			Str="";
			if(DataModeFlagirl.talk()){
				if(DataModeFlagirl.request())Str.push_back(static_cast<unsigned char>(0x10));
				else Str.push_back(static_cast<unsigned char>(0x11));
				return false;
			}
			return true;
		}
		void setup_talk(void)override{
			DataModeFlagirl.setup_talk();
		}
	private:
		hmLib::signals::unique_connections SignalConnections;
		hmLib::inquiries::unique_connections InquiryConnections;
		void setDataMode(bool Val_){DataModeFlagirl.set_request(Val_);}
		double getTemperature()const{return Temperature;}
	public:
		void contact_getTemperature(hmLib::inquiries::inquiry<double>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,[&](void)->double{return this->getTemperature();}));
		}
		void contact_getPicDataMode(hmLib::inquiries::inquiry<bool>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,[&](void)->bool{return this->DataModeFlagirl.pic();}));
		}
		void contact_getRequestDataMode(hmLib::inquiries::inquiry<bool>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,[&](void)->bool{return this->DataModeFlagirl.request();}));
		}
		void contact_getTime(hmLib::inquiries::inquiry<clock::time_point>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,Time));
		}
		void slot_setDataMode(boost::signals2::signal<void(bool)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](bool Flag)->void{this->setDataMode(Flag);}));	
		}
		void slot_setDataMode(boost::signals2::signal<void(void)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](void)->void{this->setDataMode(!(DataModeFlagirl.request()));}));	
		}
	public:
		cThermoMsgAgent():
			Temperature(0.),
			Time(),
			DataModeFlagirl(){
		}
	};
}

#
#endif