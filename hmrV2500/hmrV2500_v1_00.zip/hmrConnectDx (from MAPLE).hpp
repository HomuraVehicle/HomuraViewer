#ifdef HMR_MAIN_INC_END
#ifndef HMR_CONNECTDX_INC
#define HMR_CONNECTDX_INC 100
#

//#include "hmrDxGateSwitcher.hpp"
//#include "hmrGateSwitcher.hpp"

/*===hmrConnect===
�ڑ��⏕�֐��Q���`����
*/
//#include"hmrPublicSignal.hpp"
namespace hmr{
#if defined(HMR_DXCOM_INC) && defined(HMR_COM_INC) && defined(HMR_COMLOG_INC)
	void connect(dxosPacketList_withView<cComLog::iterator>& DxCom_,cCom& Com_,cComLog& ComLog_){
		Com_.contactRecvLog(DxCom_.inquiryNewInPacket);
		Com_.contactSendLog(DxCom_.inquiryNewOutPacket);
		ComLog_.contactLogBuf(DxCom_.inquiryPacketLog);
	}
#endif

#if defined(HMR_DXGATE_INC) && defined(HMR_GATEHAB_INC)
	void connectPartial(dxosGateSwitcher& dxosGateSwitcher_, cGateSwitcher& cGateSwitcher_){
		// GateSwUI ���@GateSwitcher�@�Ɂ@�Ȃ���
		// Switch�n�́@require signal�@���Ȃ���
		cGateSwitcher_.slot_set_and_openRS(dxosGateSwitcher_.signal_require_openRS);
		cGateSwitcher_.slot_set_and_openFOMA(dxosGateSwitcher_.signal_require_openFOMA);
		cGateSwitcher_.slot_closePort(dxosGateSwitcher_.signal_require_closeRS);
		cGateSwitcher_.slot_closePort(dxosGateSwitcher_.signal_require_closeFOMA);

		// Switch�n�́@�f�[�^�̃V���N���@���s��
		dxosGateSwitcher_.slot_sync_isFOMAOpen(cGateSwitcher_.signal_inform_isFOMAOpen);
		dxosGateSwitcher_.slot_sync_isRSOpen(cGateSwitcher_.signal_inform_isRSOpen);
	}
#endif

#if defined(HMRDXIO_INC) && defined(HMRIO_INC)
	void connectPartial(dxosIOSendBox& dxSendBox_, cFHdxIO& cIO_){
		cIO_.slot_send_direct(dxSendBox_.signal_poutString);
	}
#endif

#if defined(HMRDXIO_INC) && defined(IOLOGGATE_INC)
	typedef std::pair<bool,system_clock_iologtype> io_iologtype;
	typedef std::vector<io_iologtype> container;
	typedef container::const_iterator contanerItr;
	
	//Log Buf �Ƃ̃R�l�N�g
	//template <typename iterator> //�e���v���łǂ�����ď����΂悢�H�H
	void connectPartial(dxosIO<contanerItr>& dxosIO_, fdx_vector_iologbuf<system_clock_iologtype>& ioLog_){
		ioLog_.contactLogBuf(dxosIO_.IoLogBufInq);		
	}
	//Log Buf �\������UI�Ƃ̃R�l�N�g
	//template <typename iterator>
	void connectPartial(dxosSelectIOPaint& dxosSelectIO_, dxosIO<contanerItr>& dxosIO_){
		dxosIO_.slot_setInPaintMode(dxosSelectIO_.signal_require_paintInput);
		dxosIO_.slot_setOutPaintMode(dxosSelectIO_.signal_require_paintOutput);
		dxosIO_.contact_InPaintFlag(dxosSelectIO_.InPaintFlagInq);
		dxosIO_.contact_OutPaintFlag(dxosSelectIO_.OutPaintFlagInq);	
	}
#endif

#if defined(HMRDXIO_INC) && defined(HMR_OPERATOR_INC)
	// ���M�X�^�[�g����{�^���֘A
	void connectPartial(dxosStartControl& sendStartBut_, cFullRecvTimeSendOperator& operator_){
		operator_.slot_setIsSendActiveFlag(sendStartBut_.signal_require_setStartFlag);
		operator_.contact_IsSendActive(sendStartBut_.StartFlagInq);
	}
	
	// �S��d�A����d�̑I���֘A
	void connectPartial(dxosSelectDuplex& selDuplex_, cFullRecvTimeSendOperator& operator_){
		operator_.slot_setIsFullDuplex(selDuplex_.signal_require_isFullDuplex);
		operator_.contact_IsFullDuplex(selDuplex_.IsFullDuplexFlagInq);
	}

	// Timeout �̑I���֘A
	void connectPartial(dxosTimeOutControl& ctrTimeOut_, cFullRecvTimeSendOperator& operator_){
		operator_.slot_setTimeOut(ctrTimeOut_.signal_require_setTimeOut);
		operator_.contact_TimeOut(ctrTimeOut_.TimeOutInq);
	}

	// Time Interval �̑I���֘A
	void connectPartial(dxosTimeIntervalControl& ctrTimeInt_, cFullRecvTimeSendOperator& operator_){
		operator_.slot_setSendInterval(ctrTimeInt_.signal_require_setTimeInterval);
		operator_.contact_Interval(ctrTimeInt_.TimeIntervalInq);
	}

	// Sync Butt�֘A
	void connectPartial(dxosSyncControl& syncCtr_, cFullRecvTimeSendOperator& operator_){
		operator_.slot_setSendInterval(syncCtr_.signal_require_setTimeInterval);
		operator_.contact_IsFullDuplex(syncCtr_.IsFullDuplexInq);
		operator_.contact_Interval(syncCtr_.TimeIntervalInq);
	}
#endif

#if defined(HMRDXIO_INC) && defined(HMR_BUFGATE_INC)
	// Buf clear �֘A
	//  sendBuf or RecvBuf�����A�ڑ��̂Ƃ��Ɏw�肵�Ă��K�v������
	void connectPartial(dxosBufControl& bufCtr_, bufgate& bufgate_, bool isSendBuf){
		if(isSendBuf){
			bufgate_.slot_clearSendBuf(bufCtr_.signal_require_clearBuf);
			bufgate_.contact_sendBufSize(bufCtr_.BufSizeInq);
		}else{
			bufgate_.slot_clearRecvBuf(bufCtr_.signal_require_clearBuf);
			bufgate_.contact_recvBufSize(bufCtr_.BufSizeInq);		
		}
	}
#endif

// DXIO Display �ł܂Ƃ߂ăR�l�N�g����ꍇ
#if defined(HMR_DXIODISPLAY_INC)
	void connectPartial(dxosIOMainPage<contanerItr>& IOmain_){
		connectPartial(IOmain_.DxSelectIOPaint, IOmain_.DxIO);
	}
#endif

#if defined(HMR_DXIODISPLAY_INC) && defined(HMR_GATEHAB_INC)
	void connectPartial(dxosIOSubPage& IOsub_, cGateSwitcher& cGateSwitcher_){
		connectPartial(IOsub_.DxosGateSwitcher, cGateSwitcher_);
	}
#endif

#if defined(HMR_DXIODISPLAY_INC) && defined(HMRIO_INC)
	void connectPartial(dxosIOMainPage<contanerItr>& IOmain_, cFHdxIO& cIO_){
		connectPartial(IOmain_.DxSendBox, cIO_);
	}
#endif

#if defined(HMR_DXIODISPLAY_INC) && defined(IOLOGGATE_INC)
	void connectPartial(dxosIOMainPage<contanerItr>& IOmain_, fdx_vector_iologbuf<system_clock_iologtype>& ioLog_){
		connectPartial(IOmain_.DxIO, ioLog_);
	}
#endif

#if defined(HMR_DXIODISPLAY_INC) && defined(HMR_OPERATOR_INC)
	void connectPartial(dxosIOSubPage& IOsub_, cFullRecvTimeSendOperator& operator_){
		connectPartial(IOsub_.DxSendStartButt, operator_);
		connectPartial(IOsub_.DxSelectDuplex, operator_);
		connectPartial(IOsub_.DxSendTimeOutCtr, operator_);
		connectPartial(IOsub_.DxSendIntervalCtr, operator_);
		connectPartial(IOsub_.DxSyncCheckBox, operator_);
	}
#endif

#if defined(HMR_DXIODISPLAY_INC) && defined(HMR_BUFGATE_INC)
	void connectPartial(dxosIOSubPage& IOsub_, bufgate& bufgate_){
		connectPartial(IOsub_.DxSendBufCtr, bufgate_, true);
		connectPartial(IOsub_.DxReadBufCtr, bufgate_, false);
	}
#endif

// DXIO �Ɋւ���R�l�N�g���ׂĂ������ǂ�֐�
 // DxIOmain�֘A
#if defined(HMR_DXIODISPLAY_INC) && defined(HMRIO_INC) && defined(IOLOGGATE_INC)
	void connect(dxosIOMainPage<contanerItr>& IOmain_, cFHdxIO& cIO_, fdx_vector_iologbuf<system_clock_iologtype>& ioLog_){
		connectPartial(IOmain_);
		connectPartial(IOmain_, cIO_);
		connectPartial(IOmain_, ioLog_);
	}
#endif
 // DxIOsub�֘A
#if defined(HMR_DXIODISPLAY_INC) && defined(HMR_GATEHAB_INC) && defined(HMR_OPERATOR_INC) && defined(HMR_BUFGATE_INC)
	void connect(dxosIOSubPage& IOsub_, cGateSwitcher& cGateSwitcher_, cFullRecvTimeSendOperator& operator_, bufgate& bufgate_){
		connectPartial(IOsub_, cGateSwitcher_);
		connectPartial(IOsub_, operator_);
		connectPartial(IOsub_, bufgate_);
	}
#endif

// SUI �֘A�̃R�l�N�g
#if defined(HMR_DXGATE_SUI_INC) &&  defined(HMR_GATEHAB_INC)
	void connect(dxosGateSwitcherSUI& dxosGateSwitcherSUI_, cGateSwitcher& cGateSwitcher_){
		// GateSwUI ���@GateSwitcher�@�Ɂ@�Ȃ���
		// Switch�n�́@require signal�@���Ȃ���
		cGateSwitcher_.slot_set_and_openRS(dxosGateSwitcherSUI_.signal_require_openRS);
		cGateSwitcher_.slot_set_and_openFOMA(dxosGateSwitcherSUI_.signal_require_openFOMA);
		cGateSwitcher_.slot_closePort(dxosGateSwitcherSUI_.signal_require_closeRS);
		cGateSwitcher_.slot_closePort(dxosGateSwitcherSUI_.signal_require_closeFOMA);

		// Switch�n�́@�f�[�^�̃V���N���@���s��
		dxosGateSwitcherSUI_.slot_sync_isFOMAOpen(cGateSwitcher_.signal_inform_isFOMAOpen);
		dxosGateSwitcherSUI_.slot_sync_isRSOpen(cGateSwitcher_.signal_inform_isRSOpen);


		// Inquire �n��̐ڑ�
		cGateSwitcher_.contact_is_open(dxosGateSwitcherSUI_.isOpenInq);
		cGateSwitcher_.contact_can_put(dxosGateSwitcherSUI_.canSendInq);
		cGateSwitcher_.contact_can_get(dxosGateSwitcherSUI_.canGetInq);
	}
#endif

#if defined(HMR_DXBUFGATE_SUI_INC) &&  defined(HMR_BUFGATE_INC)
	void connect(dxosBufGateSUI& dxosBufGateSUI_, bufgate& bufgate_){
		// BufGate SUI 
		bufgate_.slot_clearSendBuf(dxosBufGateSUI_.signal_require_clearOutBuf);
		bufgate_.slot_clearRecvBuf(dxosBufGateSUI_.signal_require_clearInBuf);

		bufgate_.contact_sendBufSize(dxosBufGateSUI_.outBufSizeInq);
		bufgate_.contact_recvBufSize(dxosBufGateSUI_.inBufSizeInq);

		bufgate_.contact_is_open(dxosBufGateSUI_.isOpenInq);
		bufgate_.contact_can_get(dxosBufGateSUI_.canGetInq);
		bufgate_.contact_can_put(dxosBufGateSUI_.canSendInq);
	}
#endif

#if defined(HMR_DXIOLOGGATE_SUI_INC) &&  defined(IOLOGGATE_INC)
	typedef std::pair<bool,system_clock_iologtype> io_iologtype;
	typedef std::vector<io_iologtype> container;
	typedef container::const_iterator contanerItr;
	
	//Log Buf �Ƃ̃R�l�N�g
	//template <typename iterator>
	void connect(dxosIOLogGateSUI& dxosLogSUI_, iologgate<fdx_crlf_timeout_iologger<system_clock_iologtype>>& logGate_, fdx_vector_iologbuf<system_clock_iologtype>& logBuf_){
		logBuf_.slot_clearLogBuf(dxosLogSUI_.signal_require_clearBuf);
		logBuf_.contactLogBufSize(dxosLogSUI_.BufSizeInq);

		logGate_.contact_is_open(dxosLogSUI_.isOpenInq);
		logGate_.contact_can_put(dxosLogSUI_.canSendInq);
		logGate_.contact_can_get(dxosLogSUI_.canGetInq);
	}
#endif

#if defined(HMR_DXIO_SUI_INC) && defined(HMRIO_INC)
	void connect(dxosIOSUI& IOSUI_, cFHdxIO& cIO_){
		cIO_.contact_is_open(IOSUI_.isOpenInq);
		cIO_.contact_can_get(IOSUI_.canGetInq);
		cIO_.contact_can_put(IOSUI_.canSendInq);
	}
#endif

#if defined(HMR_DXVMC_SUI_INC) && defined(HMRIO_INC) 
	void connect(dxosVMCSUI& VMCSUI_, cFHdxIO& cIO_){
		cIO_.contactRecvErr(VMCSUI_.recvErrInq);
		cIO_.contactSendErr(VMCSUI_.sendErrInq);
		cIO_.slot_VMC_clearRecvErr(VMCSUI_.signal_require_clear_recvErr);
		cIO_.slot_VMC_clearSendErr(VMCSUI_.signal_require_clear_sendErr);
		cIO_.slot_VMC_force_end_recv(VMCSUI_.signal_require_end_recv);
		cIO_.slot_VMC_force_end_send(VMCSUI_.signal_require_end_send);

		VMCSUI_.slot_set_forceResetRecvTime(cIO_.signal_inform_VMC_force_end_recv);
		VMCSUI_.slot_set_forceResetSendTime(cIO_.signal_inform_VMC_force_end_send);
	}
#endif

#if defined(HMR_DXOPERATOR_SUI_INC) && defined(HMR_OPERATOR_INC)
	void connect(dxosOperatorSUI& opSUI_, cFullRecvTimeSendOperator& op_){
		op_.slot_setIsSendActiveFlag(opSUI_.signal_require_setStartFlag);
		op_.slot_setIsFullDuplex(opSUI_.signal_require_isFullDuplex);
		op_.slot_setSendInterval(opSUI_.signal_require_setTimeInterval);
		op_.slot_setTimeOut(opSUI_.signal_require_setTimeOut);
		
		op_.contact_IsSendActive(opSUI_.startFlagInq);
		op_.contact_IsFullDuplex(opSUI_.isFullDuplexFlagInq);
		op_.contact_Interval(opSUI_.timeIntervalInq);
		op_.contact_TimeOut(opSUI_.timeOutInq);

		opSUI_.slot_setIsReceivedFlag(op_.signal_inform_Received);
		opSUI_.slot_setIsSendedFlag(op_.signal_inform_Sended);
		opSUI_.slot_setIsTimeOutedFlag(op_.signal_inform_TimeOut);
	}
#endif




#if defined(HMR_DXTHERMOMUI_INC) && defined(HMR_THERMO_INC)
	void connect(dxosThermoMUI& ThermoMUI_, cThermoMsgAgent& Thermo_){
		Thermo_.contact_getTemperature(ThermoMUI_.inquiry_getThermo);
		Thermo_.contact_getTime(ThermoMUI_.inquiry_getTime);
		Thermo_.contact_getPicDataMode(ThermoMUI_.IsDataModeMUIBut.Pic);
		Thermo_.contact_getRequestDataMode(ThermoMUI_.IsDataModeMUIBut.Req);
		Thermo_.slot_setDataMode(ThermoMUI_.IsDataModeMUIBut.Signal);
	}
#endif

#if defined(HMR_DXSPRITE_INC) && defined(HMR_SPRITE_INC)
	void connect(dxosSprite& Sprite_, cSpriteMsgAgent& Agent_){
		Sprite_.slot_setNewGraph(Agent_.signal_setPicture);
	}
#endif
#if defined(HMR_DXSPRITEMUI_INC) && defined(HMR_SPRITE_INC)
	void connect(dxosSpriteMUI& MUI_, cSpriteMsgAgent& Agent_){
		Agent_.slot_setInfoMode(MUI_.InfoModeMUIHead.Signal);
		Agent_.contact_getPicInfoMode(MUI_.InfoModeMUIHead.Pic);
		Agent_.contact_getRequestInfoMode(MUI_.InfoModeMUIHead.Req);

		Agent_.contact_getStatus(MUI_.inquiry_getStatus);
		Agent_.contact_getIsErr(MUI_.inquiry_getIsErr);
		Agent_.contact_getErrCode(MUI_.inquiry_getErrCode);
		Agent_.contact_getStatusTime(MUI_.inquiry_getStatusTime);
		Agent_.contact_getDataPosSize(MUI_.inquiry_getDataPosSize);
		Agent_.contact_getDataTime(MUI_.inquiry_getDataTime);

		Agent_.contact_getRequestAutoTakePicture(MUI_.AutoTakePictureMUIBut.Req);
		Agent_.contact_getPicAutoTakePicture(MUI_.AutoTakePictureMUIBut.Pic);
		Agent_.slot_setAutoTakePicture(MUI_.AutoTakePictureMUIBut.Signal);

		Agent_.slot_setTakePicture(MUI_.TakePictureMUIBut.Signal);
		Agent_.contact_getDoTakePictureFlag(MUI_.TakePictureMUIBut.Req);

		Agent_.contact_getPictureSize(MUI_.inquiry_getPictureSize);
		Agent_.slot_setPictureSize(MUI_.signal_setPictureSize);

		Agent_.contact_getRequestAutoLight(MUI_.AutoLightMUIBut.Req);
		Agent_.contact_getPicAutoLight(MUI_.AutoLightMUIBut.Pic);
		Agent_.slot_setAutoLight(MUI_.AutoLightMUIBut.Signal);

		Agent_.contact_getPicLight(MUI_.LightMUIBut.Pic);
		Agent_.contact_getRequestLight(MUI_.LightMUIBut.Req);
		Agent_.slot_setLight(MUI_.LightMUIBut.Signal);

		Agent_.contact_getRequestAutoPowerReset(MUI_.AutoPowerResetMUIBut.Req);
		Agent_.contact_getPicAutoPowerReset(MUI_.AutoPowerResetMUIBut.Pic);
		Agent_.slot_setAutoPowerReset(MUI_.AutoPowerResetMUIBut.Signal);

		Agent_.contact_getDoCommandResetFlag(MUI_.CommandResetMUIBut.Req);
		Agent_.slot_setCommandReset(MUI_.CommandResetMUIBut.Signal);

		Agent_.contact_getDoPowerResetFlag(MUI_.PowerResetMUIBut.Req);
		Agent_.slot_setPowerReset(MUI_.PowerResetMUIBut.Signal);

		Agent_.contact_getPicMiniPacketMode(MUI_.MiniPacketModeMUIBut.Pic);
		Agent_.contact_getRequestMiniPacketMode(MUI_.MiniPacketModeMUIBut.Req);
		Agent_.slot_setMiniPacketMode(MUI_.MiniPacketModeMUIBut.Signal);
	}
#endif

#if defined(HMR_DXCO2MUI_INC) && defined(HMR_CO2_INC)
	void connect(dxosCO2MUI& MUI_,cCO2MsgAgent& Agent_){
		Agent_.contact_getValue(MUI_.inquiry_getValue);
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);

		Agent_.contact_getPicPumpPW(MUI_.PumpPWMUIBut.Pic);
		Agent_.contact_getRequestPumpPW(MUI_.PumpPWMUIBut.Req);
		Agent_.slot_setPumpPW(MUI_.PumpPWMUIBut.Signal);

		Agent_.contact_getPicSensorPW(MUI_.SensorPWMUIBut.Pic);
		Agent_.contact_getRequestSensorPW(MUI_.SensorPWMUIBut.Req);
		Agent_.slot_setSensorPW(MUI_.SensorPWMUIBut.Signal);
	}
#endif

#if defined(HMR_DXACCELEMUI_INC) && defined(HMR_ACCELE_INC)
	void connect(dxosAcceleMUI& MUI_,cAcceleMsgAgent& Agent_){
		Agent_.contact_getAccelePosition(MUI_.inquiry_getAccelePosition);
		Agent_.contact_getAccelePolar(MUI_.inquiry_getAccelePolar);
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);

		Agent_.slot_setCorrection(MUI_.CorrectionDataBut.Signal);
		Agent_.contact_getCorrectionFlag(MUI_.CorrectionDataBut.Req);
		Agent_.contact_getCorrectionValue(MUI_.inquiry_getCorrectionValue);
	}
#endif

#if defined(HMR_DXCOMPASSMUI_INC) && defined(HMR_COMPASS_INC)
	void connect(dxosCompassMUI& MUI_,cCompassMsgAgent& Agent_){
		Agent_.contact_getCompassPositon(MUI_.inquiry_getCompassPossition);
		Agent_.contact_getCompassPolar(MUI_.inquiry_getCompassPolar);
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);

		Agent_.contact_getCorrectionMode(MUI_.CorrectionDataBut.Req);
		Agent_.slot_setCorrectionMode(MUI_.CorrectionDataBut.Signal);
		Agent_.contact_getCompassCorrectionData(MUI_.inquiry_getCorrectionValue);
	}
#endif

#if defined(HMR_DXGYROMUI_INC) && defined(HMR_GYRO_INC)
	void connect(dxosGyroMUI& MUI_,cGyroMsgAgent& Agent_){
		Agent_.contact_getGyroData(MUI_.inquiry_getGyroData);
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);

		Agent_.slot_setCorrectionFlag(MUI_.CorrectionDataBut.Signal);
		Agent_.contact_getCorrectionFlag(MUI_.CorrectionDataBut.Req);
		Agent_.contact_getGyroCorrectionData(MUI_.inquiry_getCorrectionValue);
	}
#endif


#if defined(HMR_DXGPSMUI_INC) && defined(HMR_GPS_INC)
	void connect(dxosGPSMUI& MUI_,cGPSMsgAgent& Agent_){
		Agent_.contact_getGPSData(MUI_.inquiry_getGPSData);
//		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);
	}
#endif

#if defined(HMR_DXINFRAREDMUI_INC) && defined(HMR_INFRARED_INC)
	void connect(dxosInfraRedMUI& MUI_,cInfraRedMsgAgent& Agent_){
		Agent_.contact_getTemperature(MUI_.inquiry_getTemperature);
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);
	}
#endif

#if defined(HMR_DXHUMIDMUI_INC) && defined(HMR_HUMID_INC)
	void connect(dxosHumidMUI& MUI_,cHumidMsgAgent& Agent_){
		Agent_.contact_getValue(MUI_.inquiry_getValue);
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);
	}
#endif

#if defined(HMR_DXH2SMUI_INC) && defined(HMR_H2S_INC)
	void connect(dxosH2SMUI& MUI_,cH2SMsgAgent& Agent_){
		Agent_.contact_getValue(MUI_.inquiry_getValue);
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);
	}
#endif

#if defined(HMR_DXBATTERYMUI_INC) && defined(HMR_BATTERY_INC)
	template<unsigned int Num_>
	void connect(dxosBatteryMUI<Num_>& MUI_,cBatteryMsgAgent<Num_>& Agent_){
		for(unsigned int Cnt=0;Cnt<Num_;++Cnt){
			Agent_.contact_getBatteryData(Cnt,MUI_.inquiry_getBatteryData[Cnt]);
		}
		Agent_.contact_getTime(MUI_.inquiry_getTime);

		Agent_.contact_getPicDataMode(MUI_.IsDataModeMUIBut.Pic);
		Agent_.contact_getRequestDataMode(MUI_.IsDataModeMUIBut.Req);
		Agent_.slot_setDataMode(MUI_.IsDataModeMUIBut.Signal);
	}
#endif

#if defined(HMR_DXMOTORMUI_INC) && defined(HMR_MOTOR_INC)
	void connect(dxosMotorMUI& MUI_,cMotorMsgAgent& Agent_){
		Agent_.slot_setStickL(MUI_.Signal_MotorStickL);
		Agent_.contact_StickL(MUI_.inquiry_getMotorStickL);
		Agent_.slot_setStickR(MUI_.Signal_MotorStickR);
		Agent_.contact_StickR(MUI_.inquiry_getMotorStickR);

		Agent_.slot_setBackMode(MUI_.Signal_BackMode);
		Agent_.contact_BackMode(MUI_.inquiry_getBackMode);
	}
#endif
#if defined(HMR_DXNAVIGATOR_INC) && defined(HMR_ACCELE_INC) && defined(HMR_COMPASS_INC) && defined(HMR_GYROLOGGER_INC)
	void connect(dxosNavigator<hmr::cGyroLogger::iterator>& Navigator_,cAcceleMsgAgent& Accele_,cCompassMsgAgent& Compass_,cGyroLogger& GyroLogger_){
		Accele_.contact_getAccelePolar(Navigator_.inquiry_accele);
		Compass_.contact_getCompassPolar(Navigator_.inquiry_compass);
		GyroLogger_.contact_getLogs(Navigator_.range_inquiry_gyro);
	}
#endif


#if defined(HMR_DXCOMSUI_INC) && defined(HMR_COM_INC)
	void connect(dxosComSUI& ComBUI,cCom& Com){
		Com.contactRecvBufSize(ComBUI.inquiry_RecvBufSize);
		Com.contactSendBufSize(ComBUI.inquiry_SendBufSize);
//		Com.contactRecvLogSize(ComBUI.inquiry_RecvLogSize);
//		Com.contactSendLogSize(ComBUI.inquiry_SendLogSize);
	}
#endif
}
#
#endif
#endif
