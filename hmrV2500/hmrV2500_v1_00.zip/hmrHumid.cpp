#ifndef HMR_HUMID_CPP_INC
#define HMR_HUMID_CPP_INC 100
#

#include"hmrHumid.hpp"

//const double hmr::cHumidMsgAgent::D_ADMaxValue=4096.;

#
#endif