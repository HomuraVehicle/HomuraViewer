#ifndef HMR_BATTERY_CPP_INC
#define HMR_BATTERY_CPP_INC 101
#

#ifndef HMR_BATTERY_INC
#include "hmrBattery.hpp"
#endif

//const double hmr::cBatteryMsgAgent::D_ADMaxValue=4096.;
//const unsigned char hmr::cBatteryMsgAgent::BatteryNum=HMR_BATTERY_NUM;

#
#endif