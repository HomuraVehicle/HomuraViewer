#ifndef HMR_DXMUI_CPP_INC
#define HMR_DXMUI_CPP_INC
#
#include"hmLibVer.hpp"
#include<hmLib_v3_05/config_vc.h>
#include"hmrDxMUI.hpp"
#include<hmLib_v2/dxColorSet.hpp>
namespace hmr{
	dxosMUI::color_set dxosMUI::DefaultClr;
}
#
#endif
