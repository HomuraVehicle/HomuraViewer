#ifdef HMR_MAIN_INC_END
#ifndef HMR_CONNECTMODULE_INC
#define HMR_CONNECTMODULE_INC 100
#

//#include "hmrDxGateSwitcher.hpp"
//#include "hmrGateSwitcher.hpp"

/*===hmrConnect===
�ڑ��⏕�֐��Q���`����
*/
namespace hmr{
#if defined(HMR_GYROLOGGER_INC) && defined(HMR_GYRO_INC)
	void connect(cGyroLogger& GyroLog_,cGyroMsgAgent& Gyro_){
		GyroLog_.slot_addLog(Gyro_.signal_newdata);
	}
#endif




}
#
#endif
#endif