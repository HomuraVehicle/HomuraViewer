#ifndef HMR_MOTOR_INC
#define HMR_MOTOR_INC 101
#

/*=====hmrMotor======
hmrMotor v1_01/130602 iwahori
	�L�[�{�[�h�E�p�b�h�p��slot_setDataMode()��ǉ�(������void(void)�ɂȂ��Ă���)
hmrMotor v1_00/130427 iwahori
	cMotorMsgAgent��signal-slot,inquiry-contact�ւ̑Ή�����
*/
#include "hmLibVer.hpp"
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include <hmLib_v3_05/inquiries.hpp>
#include "hmrItfMessage.hpp"
#include "hmrFlagirl.hpp"

namespace hmr{
	class cMotorMsgAgent:public itfMessageAgent{
	private:
		bool BackMode;
		char StickL;
		bool BrakeL;
		char StickR;
		bool BrakeR;
		bool SendMotorCom;			//���[�^�[�o�͑��M�t���O
	public:
		cMotorMsgAgent():
			BackMode(false),
			StickL(0),
			BrakeL(false),
			StickR(0),
			BrakeR(false){
		}
		bool listen(datum::time_point _time,bool _errFlag,const std::string& _data)override{
			return true;
		}
		void setup_talk(void)override{
			SendMotorCom = true;
		}
		bool talk(std::string& Str)override{
			if(SendMotorCom){
				SendMotorCom = false;
				Str="";
				if(!BackMode){
					Str.push_back(static_cast<char>(StickL));
					Str.push_back(static_cast<char>(BrakeL));
					Str.push_back(static_cast<char>(StickR));
					Str.push_back(static_cast<char>(BrakeR));
				}else{
					Str.push_back(static_cast<char>(~StickR));
					Str.push_back(static_cast<char>(BrakeR));
					Str.push_back(static_cast<char>(~StickL));
					Str.push_back(static_cast<char>(BrakeL));				
				}
				return false;
			}else{
				return true;
			}
		}
	private:
		hmLib::signals::unique_connections SignalConnections;
		hmLib::inquiries::unique_connections InquiryConnections;
		void setBackMode(bool Mode_){BackMode=Mode_;}
		void setStickL(char Val_){StickL=Val_;}
		void setBrakeL(bool Mode_){BrakeL=Mode_;}
		void setStickR(char Val_){StickR=Val_;}
		void setBrakeR(bool Mode_){BrakeR=Mode_;}
		bool getBackMode()const{return BackMode;}
	public:
		void slot_setBackMode(boost::signals2::signal<void(bool)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](bool Flag)->void{this->setBackMode(Flag);}));	
		}
		void slot_setBackMode(boost::signals2::signal<void(void)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](void)->void{this->setBackMode(!BackMode);}));	
		}

		void slot_setStickL(boost::signals2::signal<void(char)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](char Val_)->void{this->setStickL(Val_);}));	
		}
		void slot_setStickL(boost::signals2::signal<void(Pint)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](Pint point_)->void{this->setStickL(point_.y);}));	
		}
		void slot_setBrakeL(boost::signals2::signal<void(bool)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](bool Flag)->void{this->setBrakeL(Flag);}));	
		}
		void slot_setBrakeLON(boost::signals2::signal<void(void)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](void)->void{this->setBrakeL(true);}));	
		}
		void slot_setBrakeLOFF(boost::signals2::signal<void(void)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](void)->void{this->setBrakeL(false);}));
		}

		void slot_setStickR(boost::signals2::signal<void(char)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](char Val_)->void{this->setStickR(Val_);}));	
		}
		void slot_setStickR(boost::signals2::signal<void(Pint)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](Pint point_)->void{this->setStickR(point_.y);}));	
		}
		void slot_setBrakeR(boost::signals2::signal<void(bool)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](bool Flag)->void{this->setBrakeR(Flag);}));	
		}
		void slot_setBrakeRON(boost::signals2::signal<void(void)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](void)->void{this->setBrakeR(true);}));	
		}
		void slot_setBrakeROFF(boost::signals2::signal<void(void)>& Signal_){
			SignalConnections(hmLib::signals::connect(Signal_,[&](void)->void{this->setBrakeR(false);}));	
		}

		void contact_BackMode(hmLib::inquiries::inquiry<bool>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,[&](void)->bool{return this->getBackMode();}));
		}
		void contact_StickL(hmLib::inquiries::inquiry<char>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,StickL));
		}
		void contact_StickR(hmLib::inquiries::inquiry<char>& Inquiry_){
			InquiryConnections(hmLib::inquiries::connect(Inquiry_,StickR));
		}

	};
}

#
#endif
