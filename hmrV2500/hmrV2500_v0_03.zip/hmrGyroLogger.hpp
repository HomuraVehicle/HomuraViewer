#ifndef HMR_GYROLOGGER_INC
#define HMR_GYROLOGGER_INC 100
#
/*===hmrGyroLogger===
Gyro�̃f�[�^����莞�Ԓ~�ς�������
*/
#include<vector>
#include<boost/signals2.hpp>
#include<hmLib_v3_05/signals.hpp>
#include<hmLib_v3_05/inquiries.hpp>
#include"coordinates.hpp"
#include"hmrData.hpp"
namespace hmr{
	class cGyroLogger{
		typedef hmLib::coordinates3D::angle angle;
		typedef std::pair<hmr::clock::time_point,angle> pair_time_angle;
		typedef std::vector<pair_time_angle> containor;
	public:
		typedef containor::const_reverse_iterator iterator;
	private:
		containor Log;
		hmLib::signals::unique_connections SignalConnections;
		hmLib::inquiries::unique_connections InquiryConnections;
	public:
		void slot_addLog(boost::signals2::signal<void(angle)>& Signal_){
			SignalConnections(
				hmLib::signals::connect(
					Signal_,
					[&](angle Angl_)->void{this->Log.push_back(std::make_pair(hmr::clock::now(),Angl_));}
				)
			);
		}
		void contact_getLogs(hmLib::inquiries::range_inquiry<iterator>& RangeInquiry_){
			InquiryConnections(
				hmLib::inquiries::connect(
					RangeInquiry_,
					[&](void)->iterator{return this->Log.rbegin();},
					[&](void)->iterator{return this->Log.rend();}
				)
			);

		}
	};
}
#
#endif
