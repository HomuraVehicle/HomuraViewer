#ifndef HMR_GPSDATASET_INC
#define HMR_GPSDATASET_INC 100
#

#include"hmLibVer.hpp"
#include"hmrData.hpp"
#include<hmLib_v3_05/position.hpp>
namespace hmr{
	class GPSDataSet{
	public:
		typedef hmLib::pdouble pdouble;
	private:
		//�g�p����GPS
		int UseGPS;
		pdouble Pos;
		double	Height;
		clock::time_point Time;
		clock::time_point UTC;
		bool failFlag;
		bool errFlag;
	public:
		GPSDataSet():
			UseGPS(0),
			Pos(0.,0.),
			Height(0.),
			Time(),
			UTC(),
			failFlag(false),
			errFlag(false){
		}
		//�R���X�g���N�^
		GPSDataSet(pdouble _Pos,double _Height,clock::time_point _Time, clock::time_point _UTC,bool _failFlag,bool _errFlag,int _UseGPS):
			UseGPS(_UseGPS),
			Pos(_Pos),
			Height(_Height),
			Time(_Time),
			UTC(_UTC),
			failFlag(_failFlag),
			errFlag(_errFlag){
		}
		//operator�I�[�o�[���C�h
		bool operator<(const GPSDataSet& _dat)const{return Time<_dat.Time;}
//		const Datum& operator=(const Datum& _dat){return *this;}
		//�e�f�[�^�擾�p�֐�
		int getUseGPS()const{return UseGPS;}
		pdouble getPos()const{return Pos;}
		double getHeight()const{return Height;}
		clock::time_point getTime()const{return Time;}
		clock::time_point getUTC()const{return UTC;}
		bool getErr()const{return errFlag;}
		bool getFail()const{return failFlag;}
	};
}

#
#endif