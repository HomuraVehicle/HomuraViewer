#ifndef HMR_DXNAVIGATOR_INC
#define HMR_DXNAVIGATOR_INC
#
/*===dxNavigator===
�����x�v�A�R���p�X�A�W���C���̓����`��N���X
*/
#include<hmLib_v3_05/inquiries.hpp>
#include"hmLibVer.hpp"
#include<hmLib_v2/dxObject.hpp>
#include<hmLib_v2/dxArea.hpp>
#include<hmLib_v2/dxColorSet.hpp>
#include"coordinates.hpp"
namespace hmr{
	template<typename gyro_iterator_>
	class dxosNavigator:public dxReObject,public hmoBox{
	private:
		dxGraph FrameGrp;
		dxGraph AcceleGrp;
		dxGraph CompassGrp;
		dxArea AcceleArea;
		dxArea CompassArea;
	public:
		class dxfnAccele:public dxFn{
			dxGraph& AcceleGrp;
			hmLib::coordinates3D::polar Accele;
		public:
			dxfnAccele(dxGraph& AcceleGrp_,hmLib::coordinates3D::polar Accele_)
				:AcceleGrp(AcceleGrp_)
				,Accele(Accele_){
			}
			int fndraw(dxO& dxo){
				dxo.draw(Pint(120,120),dxoRotGraph(AcceleGrp,1.0,Accele.theta,Pint(120,static_cast<int>(Accele.phi/pi()*180*4)+960)));
				return 0;
			}
		};
		class dxfnCompass:public dxFn{
			dxGraph& CompassGrp;
			hmLib::coordinates3D::polar Compass;
			hmLib::inquiries::range_inquiry<gyro_iterator_>& Gyro;
		public:
			dxfnCompass(dxGraph& CompassGrp_,hmLib::coordinates3D::polar Compass_,hmLib::inquiries::range_inquiry<gyro_iterator_>& Gyro_)
				:CompassGrp(CompassGrp_)
				,Compass(Compass_)
				,Gyro(Gyro_){
			}
			int fndraw(dxO& dxo){
				dxo.draw(Pint(120,120),dxoRotGraph(CompassGrp,1.0,Compass.phi,Pint(120,120)));

				if(Gyro.is_connect()){
					hmr::clock::time_point now=hmr::clock::now();
					hmLib::coordinates3D::angle Angle(0,0,0);
					for(auto itr=Gyro.begin();itr!=Gyro.end();++itr){
						std::chrono::seconds Sec=std::chrono::duration_cast<std::chrono::seconds>(now-itr->first);
						if(Sec>std::chrono::seconds(15))break;
						Angle&=(~itr->second);
						dxo.draw(Pint(120,120),dxoPLine(Pint(-80*sin(Angle.yaw),-80*cos(Angle.yaw)),Pint(40*sin(Angle.yaw),40*cos(Angle.yaw)),dxHSV(static_cast<int>(Sec.count())*10,196,196)),true,dxDMode(196));
					}
				}

				return 0;
			}
		};
	public:
		hmLib::inquiries::inquiry<hmLib::coordinates3D::polar> inquiry_accele;
		hmLib::inquiries::inquiry<hmLib::coordinates3D::polar> inquiry_compass;
		hmLib::inquiries::range_inquiry<gyro_iterator_> range_inquiry_gyro;
	public:
		dxosNavigator():hmoBox(Pint(240,360)){}
		int redraw(dxO& dxo)override{
			dxfnAccele FnAccele(AcceleGrp,inquiry_accele());
			AcceleArea.set(FnAccele,Pint(240,240));
			dxo.draw(Pint(0,0),AcceleArea);

			dxfnCompass FnCompass(CompassGrp,inquiry_compass(),range_inquiry_gyro);
			CompassArea.set(FnCompass,Pint(240,120));
			dxo.draw(Pint(0,240),CompassArea);

			dxo.draw(Pint(0,0),dxoGraph(FrameGrp,true));
			return 0;
		}
		void ini(){
			AcceleGrp.open("hmr/Accele2.png");
			CompassGrp.open("hmr/Compass2.png");
			FrameGrp.open("hmr/Frame2.png");
		}
	};
}
#
#endif
